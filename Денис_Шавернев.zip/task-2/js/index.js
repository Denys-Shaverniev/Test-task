
let open = document.querySelectorAll('.image')
let popup = document.querySelectorAll('.image__item-inner')
let close = document.querySelectorAll('.close')
let imageItem = document.querySelectorAll('.image__item')


open.forEach(img => img.addEventListener('click', (e) => {
    for(let i = 0; i < open.length; i++) {
        for(let k = 0; k < popup.length; k++) {
            if(e.target === open[i]) {
                popup[i].classList.add('active')
                document.body.style.overflow = 'hidden'
            }
        }
    }
})) 

function closeModal() {
    popup.forEach(elem => elem.classList.remove('active'))
    document.body.style.overflow = ''
}

close.forEach(btn => btn.addEventListener('click', closeModal))

let deleteButtons = document.querySelectorAll('.delete')


let count = document.querySelector('.count')
let calc = 12
count.innerHTML = `Количество изображений: ${calc}`


deleteButtons.forEach(btn => btn.addEventListener('click', (e) => {
    for(let i = 0; i < deleteButtons.length; i++) {
        for(let k = 0; k < imageItem.length; k++) {
            if(e.target === deleteButtons[i]) {  
              imageItem[i].classList.add('deleted')
              console.log(popup.length);
            }
          }
        }
        calc--
        count.innerHTML = `Количество изображений: ${calc}`
}))


let date = document.querySelector('.date')


function clock(){
  let currentDate = new Date().toLocaleDateString()
  var date = new Date(),
        hours = (date.getHours() < 10) ? '0' + date.getHours() : date.getHours(),
        minutes = (date.getMinutes() < 10) ? '0' + date.getMinutes() : date.getMinutes(),
        seconds = (date.getSeconds() < 10) ? '0' + date.getSeconds() : date.getSeconds();
  document.querySelector('.date').innerHTML = currentDate + ' ' + hours + ':' + minutes;
}
setInterval(clock, 1000);
clock();

